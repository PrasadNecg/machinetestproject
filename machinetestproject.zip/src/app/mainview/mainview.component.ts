import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainview',
  templateUrl: './mainview.component.html',
  styleUrls: ['./mainview.component.css']
})
export class MainviewComponent implements OnInit {

  constructor() { }

  ngOnInit() { 
    
  }
  searchText; 
  employees = [
    { name: 'Mr.kumar', dept: 'Accounts',jobtitle:'Junior Acct',status:'Contractor',connection:'Accepted' },
    { name: 'Mr.Sathish', dept: 'Software Dept',jobtitle:'Junior Software',status:'Furloughed',connection:'Queued' },
    { name: 'Mr.John', dept: 'HR',jobtitle:'Junior HR',status:'Full-Time',connection:'Invited' }   
  ];
}
